package com.anja.mlbbidtools;

import android.app.Activity;
import android.os.Bundle;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity {
    private final SecureRandom random = new SecureRandom();
    private final List<String> history = new ArrayList<>();
    private TextView idView, historyView;
    private final int bg = Color.rgb(13, 17, 28);
    private final int panel = Color.rgb(25, 32, 49);
    private final int accent = Color.rgb(73, 155, 255);
    private final int white = Color.WHITE;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        buildUi();
        generateId();
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(bg);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(22), dp(28), dp(22), dp(24));
        scroll.addView(root);

        TextView title = text("MLBB ID TOOLS", 26, white, true);
        title.setGravity(Gravity.CENTER);
        root.addView(title);
        TextView subtitle = text("Random ID Generator • Test utility", 13, Color.LTGRAY, false);
        subtitle.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams sp = params(-1, -2);
        sp.bottomMargin = dp(24);
        root.addView(subtitle, sp);

        TextView label = text("GENERATED ID", 12, accent, true);
        root.addView(label, params(-1, -2));

        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(16), dp(16), dp(16), dp(16));
        card.setBackgroundColor(panel);
        LinearLayout.LayoutParams cp = params(-1, -2);
        cp.topMargin = dp(8);
        cp.bottomMargin = dp(16);
        root.addView(card, cp);

        idView = text("", 16, white, true);
        idView.setTypeface(Typeface.MONOSPACE);
        idView.setTextIsSelectable(true);
        card.addView(idView);

        Button generate = button("GENERATE ID");
        generate.setOnClickListener(v -> generateId());
        root.addView(generate, buttonParams());

        Button copy = button("COPY TO CLIPBOARD");
        copy.setOnClickListener(v -> copyId());
        root.addView(copy, buttonParams());

        TextView historyLabel = text("RECENT HISTORY", 12, accent, true);
        LinearLayout.LayoutParams hp = params(-1, -2);
        hp.topMargin = dp(18);
        root.addView(historyLabel, hp);

        historyView = text("Belum ada riwayat.", 13, Color.LTGRAY, false);
        historyView.setTypeface(Typeface.MONOSPACE);
        LinearLayout.LayoutParams htp = params(-1, -2);
        htp.topMargin = dp(8);
        root.addView(historyView, htp);

        TextView note = text("Catatan: ID ini dibuat secara acak untuk simulasi/testing. Tidak mengubah Device ID yang dibaca Mobile Legends dan tidak dijamin valid di server game.", 12, Color.rgb(180, 190, 210), false);
        LinearLayout.LayoutParams np = params(-1, -2);
        np.topMargin = dp(24);
        root.addView(note, np);
        setContentView(scroll);
    }

    private void generateId() {
        // Similar visual pattern: 52 hex chars, hyphen, then UUID-like 4-4 groups with trailing hyphen.
        String value = hex(52) + "-" + hex(4) + "-" + hex(4) + "-";
        idView.setText(value);
        history.add(0, value);
        while (history.size() > 8) history.remove(history.size() - 1);
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < history.size(); i++) {
            b.append(i + 1).append(". ").append(history.get(i));
            if (i < history.size() - 1) b.append("\n\n");
        }
        historyView.setText(b.toString());
    }

    private String hex(int length) {
        final char[] chars = "0123456789abcdef".toCharArray();
        StringBuilder b = new StringBuilder(length);
        for (int i = 0; i < length; i++) b.append(chars[random.nextInt(chars.length)]);
        return b.toString();
    }

    private void copyId() {
        ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        cm.setPrimaryClip(ClipData.newPlainText("Generated test ID", idView.getText().toString()));
        Toast.makeText(this, "ID disalin", Toast.LENGTH_SHORT).show();
    }

    private Button button(String label) {
        Button b = new Button(this);
        b.setText(label);
        b.setTextColor(white);
        b.setAllCaps(false);
        b.setTextSize(14);
        b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(accent));
        return b;
    }

    private LinearLayout.LayoutParams buttonParams() {
        LinearLayout.LayoutParams p = params(-1, -2);
        p.bottomMargin = dp(10);
        return p;
    }

    private TextView text(String value, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(size);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    private LinearLayout.LayoutParams params(int w, int h) {
        return new LinearLayout.LayoutParams(w, h);
    }

    private int dp(int n) {
        return (int)(n * getResources().getDisplayMetrics().density + 0.5f);
    }
}
