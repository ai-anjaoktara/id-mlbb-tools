# MLBB ID Tools (simulator)

A small Android project that generates random hexadecimal IDs in a configurable format similar to the example provided. These are random test strings only; they are not guaranteed to be valid Mobile Legends identifiers and do not change the ID read by the game.

## Build
Open this folder in Android Studio, allow Gradle sync, then Build > Build APK(s).

Requirements: Android Studio with Android SDK installed. This project uses a standard Android Gradle plugin setup.
